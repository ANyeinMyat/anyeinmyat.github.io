# -*- encoding=utf8 -*-
__author__ = "Anantha.k"
from airtest.core.api import *
from poco.drivers.unity3d import UnityPoco
poco = UnityPoco()
from poco.drivers.ios import iosPoco
from  airtest.core.device  import  Device
import sys
from datetime import datetime
from datetime import timedelta, date
from airtest.report.report import *
import re
import os
sys.path.append('/usr/local/bin/python3')
poco = iosPoco() 
class TicketMelonSanity:
    def __init__(self):
            return   
    def launchTmApp(self):
            self.closeTheExistingApp()
            log("Launch",desc="LAUNCH THE TEST FLIGHT APPLICATION")
            start_app("com.apple.TestFlight")
            installalert = poco(name="INSTALL")
            if  installalert.exists():
                    log("Launch",desc="INSTALL THE TICKETMELON APPLICATION")
                    poco(name="INSTALL").click()
                    poco(name="OPEN").wait_for_appearance()    
                    poco(name="OPEN").click()
                    poco(name="Next").wait_for_appearance()
                    poco(name="Next").click()
                    poco(name="Start Testing").wait_for_appearance()
                    poco(name="Start Testing").click()
                    poco(name="EN").wait_for_appearance()
                    poco(name="EN").click()
                    poco(name="DONE").click()
                    poco(name="Get Started →").wait_for_appearance()
                    poco(name="Get Started →").click()
                    self.trackActivity()
                    poco(name="Email Address").wait_for_appearance()
                    self.loginToApp()
            else:    
                    log("OPEN",desc="OPEN THE TICKETMELON APPLICATION")
                    poco(name="OPEN").wait_for_appearance()    
                    poco(name="OPEN").click()
            
    def searchEvent(self,args):
            log("SEARCH",desc="SEARCH THE EVENT NAME: "+args)
            poco(label="SearchStack, tab, 2 of 4").click()
            poco(label="").wait_for_appearance()
            poco(label="").click()
            self.findEvents()
            poco(label="").click()
            text(args)
            if  poco(label="Hmm. No results!").exists():
                log("EVENT",desc="EVENT NOT FOUND")
            else:
                poco(type="ScrollView").child().click()
                poco(label="Get tickets").wait_for_appearance()
                poco(label="Get tickets").click()
            if  poco(label=args).exists():
                log("EVENT",desc="EVENT SEARCH SUCCESSFUL")
    def loginToApp(self):
            log("Login",desc="LOG INTO THE APPLICATION")
            poco(label="Email Address").click()
            text("roan.l@rznet.com")
            poco(label="Password").click()
            text("Libelo05!")
            poco(name="Sign In").click()
            poco(label="ProfileStack, tab, 4 of 4").wait_for_appearance()
    def bookTicket(self):
            log("Book",desc="PAYMENT FOR THE TICKET")
            if  poco(label="0").exists():
                (poco("Window").child("Other").child("Other").child("Other").offspring("Button")[1]).click()
                poco(label="Continue").click()
                sleep(5)
                itempaynow=poco(label="Pay Now")
                while not (itempaynow.exists()):
                    swipe((1000, 1000), (200, 200),duration=1, steps=10)
                log("PAYNOW",desc="PAY NOW IS ENABLED")
                poco(label="By checking out, I agree to Ticketmelon's Terms of Service and Event Organizer's Disclaimer. I accept that the items in this order cannot be canceled and payments are non-refundable.").click()
                assert_equal(str(poco(label="Pay Now").attr("isEnabled")), "1", "The pay now button is enabled")
                log("PAYNOW",desc="PAY NOW IS DISABLED")
                poco(label="By checking out, I agree to Ticketmelon's Terms of Service and Event Organizer's Disclaimer. I accept that the items in this order cannot be canceled and payments are non-refundable.").click()
                assert_equal(str(poco(label="Pay Now").attr("isEnabled")), "0", "The pay now button is disabled")
                poco(name="Button").click()
                sleep(2)
                poco(name="Button").click()
                sleep(2)
                poco(name="Button").click()
    def closeTheExistingApp(self):
        try:
            stop_app("com.ticketmelon.app.attendee")
            print("Ticketmelon app is closed")
            stop_app("com.apple.TestFlight")   
            print("Testflight app is closed")
        except:    
            print("An exception occurred in closing the opened apps")
    def trackActivity(self):
            trackalert = poco(label="Ask App Not to Track")
            if  trackalert.exists():
                    trackalert.click()
                    """
    def ticketHistory(self,args1,args2):
            log("HISTORY",desc="TICKET HISTORY")
            poco(label="MyticketStack, tab, 3 of 4").wait_for_appearance()
            poco(label="MyticketStack, tab, 3 of 4").click()
            poco(label="Upcoming").wait_for_appearance()
            presentDay = datetime.now()
            presentDate = presentDay.strftime("%d-%m-%Y")
            print(presentDate)
            presentDateDay=presentDate.split("-")
            presentDateToday=(presentDateDay[0])
            print(presentDateToday)
            presentDateMonth=presentDateDay[1]
            if  ("0" in presentDateMonth and presentDateMonth !="10"):
                    presentDateMonth=presentDateMonth.replace("0","")
                    print(presentDateMonth)
            presentDateMonth1=self.numbersToStrings(presentDateMonth)
            print(presentDateMonth1)
            futurdate=date.today() + timedelta(days=81)
            futureDate = futurdate.strftime("%d-%m-%Y")
            print(futureDate)
            futureDates=futureDate.split("-")
            futureDateToday=futureDates[0]
            futureDateToday= re.sub("<\/?\[[0-9]+>", " - ", futureDateToday)
            futureDateMonth=futureDates[1]
            if  ("0" in futureDateMonth and futureDateMonth !="10"):
                    futureDateMonth=futureDateMonth.replace("0","")
                    print(futureDateMonth)
            futureDateMonth1=self.numbersToStrings(futureDateMonth)
            re.sub("[A-Z]*", "[A-Z]", futureDateMonth1)
            re.sub("[a-z]* [A-Z]", "[a-z]", futureDateMonth1)
            print(futureDateMonth1)
            itemevant = poco("Window").child("Other").child("Other").child("Other").offspring(""+args1+"" " Tickets "+presentDateToday+" "+presentDateMonth1+" - "+futureDateToday+" "+futureDateMonth1+" "+args2+" Tracking View Ticket")
            print(itemevant)
            self.scrollevant(itemevant)
            sleep(2)
            assert_equal(str(poco(name=""+args2+"").attr("label")), ""+args2+"", "The Ticket details are displayed successfully")
            snapshot(msg=""+args2+"")
            poco(label="E-Tickets").child(name="Other").child(name="Other").click()
            """
    def ticketHistory(self,ticket,args1,flag):
            log("HISTORY",desc="TICKET HISTORY")
            poco(label="MyticketStack, tab, 3 of 4").wait_for_appearance()
            poco(label="MyticketStack, tab, 3 of 4").click()
            poco(label="Upcoming").wait_for_appearance()
            evantlist=poco(name='ScrollView').sibling().attr("label")
            if flag=='yes':
                args2="Tracking View Ticket"
            else:
                args2="View Ticket"
            if ticket=="" or ticket=="0":
                ticket=="1"
            else:
                ticket=ticket    
            print("{} {}".format(args1,flag))
            evant=evantlist.split("{} {}".format(args1,args2))
            print("VJ ",evant)
            # tkt=(qw[0].split("Tickets"))[-1]
            #1 Tickets 11 May - 31 Jul Rz normal event - 11/05/2023 Tracking View Ticket
            tickat=evant[0].split(" ")
            tickatstart=tickat[-8:]
            print(tickatstart)
            evantname="{}{} {}".format(" ".join(tickatstart), args1, args2)
            print("Event search ",evantname)
            evantnew=poco(label=""+evantname+"")
            while not (evantnew.exists()):
                poco.scroll(direction="vertical", percent=0.3, duration=1)
                scrolpersentage=poco("ScrollView").offspring("ScrollView").child()[0].attr("value")
                scrolpersentage= str(scrolpersentage)
                if(scrolpersentage == "None"):
                    scrolpersentage=poco("ScrollView").offspring("ScrollView").child()[1].attr("value")
                print(scrolpersentage)
                if(scrolpersentage=="100%"):
                    break
            try:
                newposy=float("0.70")
                posx,posy=evantnew.attr("pos")
                print(posx,posy)
                if posy >= newposy:
                    poco.scroll(direction="vertical", percent=0.3, duration=1)
                    sleep(3)
                touch([0.5,0.67])
                sleep(5)
                assert_equal(str(poco(name=""+args1+"").attr("label")), ""+args1+"", "The Ticket details are displayed successfully")
                snapshot(msg="EventDetails")
                poco(label="E-Tickets").child(name="Other").child(name="Other").click()
            except:    
                print("Event not displayed")
                sys.exit()
            
    def findEvents(self):
            trackalert = poco(label=" Find events by name, or location")
            if  trackalert.exists():
                    trackalert.click()
            else:
                poco(label="").click()
                poco(label="delete").click()
                poco(label="").click()
                poco(label="Select All").click()
                poco(label="Cut").click()
    def logout(self):
        poco(label="ProfileStack, tab, 4 of 4").wait_for_appearance()
        poco(label="ProfileStack, tab, 4 of 4").click()
        poco(label="Edit Profile").wait_for_appearance()
        itemlogout=poco(label="Log out")
        while not (itemlogout.exists()):
                swipe((1000, 1000), (200, 200),duration=1, steps=10)
        versionNumber=poco(label="Log out").sibling()[-4].attr("label")
        print(versionNumber)
        poco(label="Log out").click()
        poco(label="OK").wait_for_appearance()
        poco(label="OK").click()
        presentDay=datetime.now()
        presentDate = presentDay.strftime("%d%m%Y%H%M%S")
        fylename="TmIOS_"+versionNumber+"_"+presentDate
        fylename=fylename.replace(" ","")
        print(fylename)
        simple_report("/Users/imac/Desktop/Automation/TicketmelonIOS.air",logpath="/var/folders/61/pcsxvxzd07d436tqzysq_vzm0000gn/T/AirtestIDE/scripts/d9d8c9923619c157a701a25c6a5dff02",logfile="/var/folders/61/pcsxvxzd07d436tqzysq_vzm0000gn/T/AirtestIDE/scripts/d9d8c9923619c157a701a25c6a5dff02/log.txt",output="/var/folders/61/pcsxvxzd07d436tqzysq_vzm0000gn/T/AirtestIDE/scripts/d9d8c9923619c157a701a25c6a5dff02/"+fylename+".html")
        #h1=LogToHtml("/Users/imac/Desktop/Automation/TicketmelonIOS.air", log_root="/var/folders/61/pcsxvxzd07d436tqzysq_vzm0000gn/T/AirtestIDE/scripts/d9d8c9923619c157a701a25c6a5dff02", static_root="/Applications/AirtestIDE.app/Contents/MacOS/airtest/report", export_dir="/Users/imac/Desktop/Automation/TicketmelonIOS.air/Results/"+fylename+".html", script_name="TicketmelonIOS.py", logfile="/var/folders/61/pcsxvxzd07d436tqzysq_vzm0000gn/T/AirtestIDE/scripts/d9d8c9923619c157a701a25c6a5dff02/log.txt", lang="en", plugins=None)
        #h1.report()
        self.closeTheExistingApp()
    def numbersToStrings(self,argument):
        if argument == "1":
            return "Jan"
        elif argument == "2":
                return "Feb"
        elif argument == "3":
                return "Mar"
        elif argument == "4":
                return "Apr"    
        elif argument == "5":
                return "May"    
        elif argument == "6":
                return "Jun"    
        elif argument == "7":
                return "Jul"
        elif argument == "8":
                return "Aug"
        elif argument == "9":
                return "Sep"
        elif argument == "10":
                return "Oct"
        elif argument == "11":
                return "Nov"
        elif argument == "12":
                return "Dec"    
    def scrollevant(self,args1):
            itemscroll=poco("Horizontal scroll bar, 1 page").sibling()[-3].attr("value")
            print(itemscroll)
            """
            evantscount=re.findall("[0-9][0-9]", itemscroll)
            if(type(evantscount)=="list"):
                scrolproperty="Vertical scroll bar, " ""+evantscount[0]+""+evantscount[1]+ " pages"
                print("scrolproperty List: ",scrolproperty)
            else:
                evantscount=re.findall("[0-9]", itemscroll)
                evantscount=str(evantscount)
                scrolproperty="Vertical scroll bar, " ""+evantscount+"" " pages"
            print("scrolproperty : ",scrolproperty)
            """
            while not (args1.exists()):
                swipe((1000, 1000), (200, 200),duration=1, steps=10)
                #scrolpersentage=poco("Horizontal scroll bar, 1 page").sibling()[-3].attr("value")
                scrolpersentage=poco("ScrollView").offspring("ScrollView").child()[0].attr("value")
                scrolpersentage= str(scrolpersentage)
                if(scrolpersentage == "None"):
                    scrolpersentage=poco("ScrollView").offspring("ScrollView").child()[1].attr("value")
                print(scrolpersentage)
                if(scrolpersentage=="100%"):
                    break
            try:
                args1.click()
            except:    
                print("Event not displayed")
    def eenddate(self,args1,flag):
                ananth=poco(name='ScrollView').sibling().attr("label")
                if flag=='yes':
                    args2="Tracking View Ticket"
                else:
                    args2="View Ticket"
                print("{} {}".format(args1,flag))
                qw=ananth.split("{} {}".format(args1,args2))
                # tkt=(qw[0].split("Tickets"))[-1]
                tkt=qw[0].split(" ")
                fpart=tkt[-8:]
                print(fpart)
                evantname="{}{} {}".format(" ".join(fpart), args1, args2)
                print("Event serch ",evantname)
                evant1 = str(""+evantname+"")
                evant1=poco(label=""+evantname+"")
                while not (evant1.exists()):
                    #nag=poco(label=""+nag+"").click()
                    poco.scroll(direction="vertical", percent=0.3, duration=1)
                a=float("0.70")
                x,y=evant1.attr("pos")
                print(x,y)
                x,y=evant1.attr("pos")
                if y >= a:
                    poco.scroll(direction="vertical", percent=0.3, duration=1)
                    #poco.scroll(direction="vertical", percent=0.3, duration=1)
                    sleep(3)
                    
                    #evant1.click()
                touch([0.5,0.67])
                
Object = TicketMelonSanity()
#Object.launchTmApp()
#Object.loginToApp()
#Object.searchEvent("กิจกรรมดูแลช้าง ปางช้างแม่ริม")
#Object.bookTicket()
Object.ticketHistory("1","RZ x CalView","no")
#Object.logout()